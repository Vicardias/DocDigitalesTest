
let btn_Show_Packeges_Modal = document.getElementById("btn_Show_Packeges_Modal");
let Packages_Modal = new bootstrap.Modal("#Packages_Modal");
let Video_Clip = document.querySelectorAll(".hover-to-play");

btn_Show_Packeges_Modal.addEventListener("click", () => {
    Packages_Modal.show();
});

for ( let i = 0; i < Video_Clip.length; i++ ) { 
    Video_Clip[i].addEventListener("mouseenter", () => { Video_Clip[i].play(); });
    Video_Clip[i].addEventListener("mouseout", () => { Video_Clip[i].pause(); }); 
}